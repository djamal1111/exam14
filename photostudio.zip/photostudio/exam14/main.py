import sys
from PyQt5.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget, QLabel, QLineEdit, QPushButton, QMessageBox, QTableWidget, QTableWidgetItem, QDialog, QDialogButtonBox
import pymysql
class AddEditClientDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Добавить/Редактировать клиента")

        layout = QVBoxLayout()

        self.client_name_input = QLineEdit()
        self.client_name_input.setPlaceholderText("Имя")
        layout.addWidget(self.client_name_input)

        self.client_address_input = QLineEdit()
        self.client_address_input.setPlaceholderText("Адрес")
        layout.addWidget(self.client_address_input)

        self.button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        layout.addWidget(self.button_box)
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)

        self.setLayout(layout)

    def get_data(self):
        return self.client_name_input.text(), self.client_address_input.text()

class AddEditWorkerDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Добавить/Редактировать сотрудника")

        layout = QVBoxLayout()

        self.worker_name_input = QLineEdit()
        self.worker_name_input.setPlaceholderText("Имя")
        layout.addWidget(self.worker_name_input)

        self.worker_position_input = QLineEdit()
        self.worker_position_input.setPlaceholderText("Должность")
        layout.addWidget(self.worker_position_input)

        self.worker_adress_input = QLineEdit()
        self.worker_adress_input.setPlaceholderText("Адрес")
        layout.addWidget(self.worker_adress_input)

        self.worker_phone_input = QLineEdit()
        self.worker_phone_input.setPlaceholderText("Телефон")
        layout.addWidget(self.worker_phone_input)

        self.button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        layout.addWidget(self.button_box)
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)

        self.setLayout(layout)

    def get_data(self):
        return self.worker_name_input.text(), self.worker_position_input.text(), self.worker_adress_input.text(), self.worker_phone_input.text()

class AddEditOrderDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Добавить/Редактироватьт заказ")

        layout = QVBoxLayout()

        self.client_id_input = QLineEdit()
        self.client_id_input.setPlaceholderText("Клиент")
        layout.addWidget(self.client_id_input)

        self.worker_id_input = QLineEdit()
        self.worker_id_input.setPlaceholderText("Сотрудник")
        layout.addWidget(self.worker_id_input)

        self.date_record_input = QLineEdit()
        self.date_record_input.setPlaceholderText("Дата съемки")
        layout.addWidget(self.date_record_input)

        self.date_order_input = QLineEdit()
        self.date_order_input.setPlaceholderText("Дата заказа")
        layout.addWidget(self.date_order_input)

        self.payment_input = QLineEdit()
        self.payment_input.setPlaceholderText("Стоимость")
        layout.addWidget(self.payment_input)

        self.button_box = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        layout.addWidget(self.button_box)
        self.button_box.accepted.connect(self.accept)
        self.button_box.rejected.connect(self.reject)

        self.setLayout(layout)

    def get_data(self):
        return self.client_id_input.text(), self.worker_id_input.text(), self.date_record_input.text(), self.date_order_input.text(), self.payment_input.text()


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Фотоателье")
        self.setGeometry(100, 100, 800, 600)

        layout = QVBoxLayout()

        self.client_button = QPushButton("Показать клиентов")
        self.client_button.clicked.connect(self.show_clients)
        layout.addWidget(self.client_button)

        self.worker_button = QPushButton("Показать сотрудников")
        self.worker_button.clicked.connect(self.show_workers)
        layout.addWidget(self.worker_button)

        self.order_button = QPushButton("Показать заказы")
        self.order_button.clicked.connect(self.show_orders)
        layout.addWidget(self.order_button)

        self.result_table = QTableWidget()
        layout.addWidget(self.result_table)


        self.add_client_button = QPushButton("Добавить клиента")
        self.add_client_button.clicked.connect(self.add_client)
        layout.addWidget(self.add_client_button)

        self.edit_client_button = QPushButton("Изменить данные о клиенте")
        self.edit_client_button.clicked.connect(self.edit_client)
        layout.addWidget(self.edit_client_button)

        self.delete_client_button = QPushButton("Удалить клиента")
        self.delete_client_button.clicked.connect(self.delete_client)
        layout.addWidget(self.delete_client_button)

        self.add_worker_button = QPushButton("Добавить сотрудника")
        self.add_worker_button.clicked.connect(self.add_worker)
        layout.addWidget(self.add_worker_button)

        self.edit_worker_button = QPushButton("Изменить данные о сотруднике")
        self.edit_worker_button.clicked.connect(self.edit_worker)
        layout.addWidget(self.edit_worker_button)

        self.delete_worker_button = QPushButton("Удалить сотрудника")
        self.delete_worker_button.clicked.connect(self.delete_worker)
        layout.addWidget(self.delete_worker_button)

        self.add_order_button = QPushButton("Добавить заказ")
        self.add_order_button.clicked.connect(self.add_order)
        layout.addWidget(self.add_order_button)

        self.edit_order_button = QPushButton("Изменить заказ")
        self.edit_order_button.clicked.connect(self.edit_order)
        layout.addWidget(self.edit_order_button)

        self.delete_order_button = QPushButton("Удалить заказ")
        self.delete_order_button.clicked.connect(self.delete_order)
        layout.addWidget(self.delete_order_button)

        central_widget = QWidget()
        central_widget.setLayout(layout)
        self.setCentralWidget(central_widget)

        self.db_connection = pymysql.connect(host='localhost', user='root', password='root', database='exam14')
        self.cursor = self.db_connection.cursor()
        self.show_client_orders_button = QPushButton("Показать заказы одного клиента")
        self.show_client_orders_button.clicked.connect(self.show_client_orders)
        layout.addWidget(self.show_client_orders_button)

        self.calculate_worker_bonus_button = QPushButton("Расчет ЗП")
        self.calculate_worker_bonus_button.clicked.connect(self.calculate_worker_bonus)
        layout.addWidget(self.calculate_worker_bonus_button)

        self.top_workers_button = QPushButton("Рейтинг сотрудников")
        self.top_workers_button.clicked.connect(self.top_workers)
        layout.addWidget(self.top_workers_button)

    def show_client_orders(self):
        row = self.result_table.currentRow()
        if row != -1:
            client_id = self.result_table.item(row, 0).text()
            query = "SELECT * FROM Orders WHERE ClientID = %s"
            self.cursor.execute(query, (client_id,))
            orders = self.cursor.fetchall()
            if orders:
                self.result_table.setRowCount(0)
                self.result_table.setColumnCount(len(orders[0]))
                self.result_table.setHorizontalHeaderLabels(["Номер заказа", "Клиент", "Сотрудник", "Дата съемки", "Дата выпления", "Стоимость"])
                for row_number, order in enumerate(orders):
                    self.result_table.insertRow(row_number)
                    for column_number, data in enumerate(order):
                        self.result_table.setItem(row_number, column_number, QTableWidgetItem(str(data)))
        else:
            QMessageBox.warning(self, "Ошибка", "Выберите клиента для отображения его заказов")

    def calculate_worker_bonus(self):
        query = "SELECT w.FullName, SUM(o.Payment) * 0.4 AS Bonus FROM Orders o JOIN Workers w ON o.WorkerID = w.WorkerID GROUP BY o.WorkerID"
        self.cursor.execute(query)
        worker_bonuses = self.cursor.fetchall()
        if worker_bonuses:
            bonus_text = "Имя сотрудника    |     Зарплата\n"
            for worker_bonus in worker_bonuses:
                worker_name, bonus = worker_bonus
                bonus_text += f"{worker_name}    |    {bonus}\n"
            QMessageBox.information(self, "Зарплата сотрудников", bonus_text)
        else:
            QMessageBox.warning(self, "Ошибка", "Нет данных о сотрудниках")

    def top_workers(self):
        query = "SELECT w.FullName, COUNT(o.WorkerID) AS OrdersCount FROM Orders o JOIN Workers w ON o.WorkerID = w.WorkerID GROUP BY o.WorkerID ORDER BY OrdersCount DESC LIMIT 3"
        self.cursor.execute(query)
        top_workers = self.cursor.fetchall()
        if top_workers:
            top_workers_text = "Топ 3 сотрудника:\n"
            for worker in top_workers:
                worker_name, orders_count = worker
                top_workers_text += f"{worker_name}: {orders_count} заказов\n"
            QMessageBox.information(self, "Рейтинг сотрудников", top_workers_text)
        else:
            QMessageBox.warning(self, "Ошибка", "Нет данных о сотрудниках")

    def show_clients(self):
        self.result_table.setRowCount(0)
        query = "SELECT * FROM Clients"
        self.cursor.execute(query)
        clients = self.cursor.fetchall()
        if clients:
            self.result_table.setColumnCount(len(clients[0]))
            self.result_table.setHorizontalHeaderLabels(["Клиент", "Имя", "Адрес"])
            for row_number, client in enumerate(clients):
                self.result_table.insertRow(row_number)
                for column_number, data in enumerate(client):
                    self.result_table.setItem(row_number, column_number, QTableWidgetItem(str(data)))

    def show_workers(self):
        self.result_table.setRowCount(0)
        query = "SELECT * FROM Workers"
        self.cursor.execute(query)
        workers = self.cursor.fetchall()
        if workers:
            self.result_table.setColumnCount(len(workers[0]))
            self.result_table.setHorizontalHeaderLabels(["Номер", "Имя", "Должность", "Адрес", "Телефон"])
            for row_number, worker in enumerate(workers):
                self.result_table.insertRow(row_number)
                for column_number, data in enumerate(worker):
                    self.result_table.setItem(row_number, column_number, QTableWidgetItem(str(data)))

    def show_orders(self):
        self.result_table.setRowCount(0)
        query = "SELECT * FROM Orders"
        self.cursor.execute(query)
        orders = self.cursor.fetchall()
        if orders:
            self.result_table.setColumnCount(len(orders[0]))
            self.result_table.setHorizontalHeaderLabels(["Номер заказа", "Клиент", "Сотрудник", "Дата съемки", "Дата выпления", "Стоимость"])
            for row_number, order in enumerate(orders):
                self.result_table.insertRow(row_number)
                for column_number, data in enumerate(order):
                    self.result_table.setItem(row_number, column_number, QTableWidgetItem(str(data)))


    def add_client(self):
        dialog = AddEditClientDialog()
        if dialog.exec_() == QDialog.Accepted:
            client_name, client_address = dialog.get_data()
            query = "INSERT INTO Clients (FullName, Address) VALUES (%s, %s)"
            self.cursor.execute(query, (client_name, client_address))
            self.db_connection.commit()
            self.show_clients()

    def edit_client(self):
        row = self.result_table.currentRow()
        if row != -1:
            dialog = AddEditClientDialog()
            client_id = self.result_table.item(row, 0).text()
            client_name = self.result_table.item(row, 1).text()
            client_address = self.result_table.item(row, 2).text()
            dialog.client_name_input.setText(client_name)
            dialog.client_address_input.setText(client_address)
            if dialog.exec_() == QDialog.Accepted:
                new_client_name, new_client_address = dialog.get_data()
                query = "UPDATE Clients SET FullName = %s, Address = %s WHERE ClientID = %s"
                self.cursor.execute(query, (new_client_name, new_client_address, client_id))
                self.db_connection.commit()
                self.show_clients()
        else:
            QMessageBox.warning(self, "Ошибка", "Выберите клиента для изменения")

    def delete_client(self):
        row = self.result_table.currentRow()
        if row != -1:
            client_id = self.result_table.item(row, 0).text()
            reply = QMessageBox.question(self, 'Удаление клиента', 'Вы хотите удалить клиента?', QMessageBox.Yes | QMessageBox.No)
            if reply == QMessageBox.Yes:
                query = "DELETE FROM Clients WHERE ClientID = %s"
                self.cursor.execute(query, (client_id,))
                self.db_connection.commit()
                self.show_clients()
        else:
            QMessageBox.warning(self, "Ошибка", "Выберите клиента для удаления")

    def add_worker(self):
        dialog = AddEditWorkerDialog()
        if dialog.exec_() == QDialog.Accepted:
            worker_name, worker_position, worker_adress, worker_phone = dialog.get_data()
            query = "INSERT INTO Workers (FullName, Position, adress, phone) VALUES (%s, %s, %s, %s)"
            self.cursor.execute(query, (worker_name, worker_position, worker_adress, worker_phone))
            self.db_connection.commit()
            self.show_workers()

    def edit_worker(self):
        row = self.result_table.currentRow()
        if row != -1:
            dialog = AddEditWorkerDialog()
            worker_id = self.result_table.item(row, 0).text()
            worker_name = self.result_table.item(row, 1).text()
            worker_position = self.result_table.item(row, 2).text()
            worker_adress = self.result_table.item(row, 3).text()
            worker_phone = self.result_table.item(row, 4).text()
            dialog.worker_name_input.setText(worker_name)
            dialog.worker_position_input.setText(worker_position)
            dialog.worker_adress_input.setText(worker_adress)
            dialog.worker_phone_input.setText(worker_phone)
            if dialog.exec_() == QDialog.Accepted:
                new_worker_name, new_worker_position, new_worker_adress, new_worker_phone = dialog.get_data()
                query = "UPDATE Workers SET FullName = %s, Position = %s, adress = %s, phone = %s WHERE WorkerID = %s"
                self.cursor.execute(query, (
                new_worker_name, new_worker_position, new_worker_adress, new_worker_phone, worker_id))
                self.db_connection.commit()
                self.show_workers()
        else:
            QMessageBox.warning(self, "Ошибка", "Выберите сотрудника для изменения")

    def delete_worker(self):
        row = self.result_table.currentRow()
        if row != -1:
            worker_id = self.result_table.item(row, 0).text()
            reply = QMessageBox.question(self, 'Удаление сотрудника', 'Вы хотите удалить сотрудника?', QMessageBox.Yes | QMessageBox.No)
            if reply == QMessageBox.Yes:
                query = "DELETE FROM Workers WHERE WorkerID = %s"
                self.cursor.execute(query, (worker_id,))
                self.db_connection.commit()
                self.show_workers()
        else:
            QMessageBox.warning(self, "Ошибка", "Выберите сотрудника для удаления")

    def add_order(self):
        dialog = AddEditOrderDialog()
        if dialog.exec_() == QDialog.Accepted:
            client_id, worker_id, date_record, date_order, payment = dialog.get_data()
            query = "INSERT INTO Orders (ClientID, WorkerID, date_record, date_order, Payment) VALUES (%s, %s, %s, %s, %s)"
            self.cursor.execute(query, (client_id, worker_id, date_record, date_order, payment))
            self.db_connection.commit()
            self.show_orders()

    def edit_order(self):
        row = self.result_table.currentRow()
        if row != -1:
            dialog = AddEditOrderDialog()
            order_id = self.result_table.item(row, 0).text()
            client_id = self.result_table.item(row, 1).text()
            worker_id = self.result_table.item(row, 2).text()
            date_record = self.result_table.item(row, 3).text()
            date_order = self.result_table.item(row, 4).text()
            payment = self.result_table.item(row, 5).text()
            dialog.client_id_input.setText(client_id)
            dialog.worker_id_input.setText(worker_id)
            dialog.date_record_input.setText(date_record)
            dialog.date_order_input.setText(date_order)
            dialog.payment_input.setText(payment)
            if dialog.exec_() == QDialog.Accepted:
                new_client_id, new_worker_id, new_date_record, new_date_order, new_payment = dialog.get_data()
                query = "UPDATE Orders SET ClientID = %s, WorkerID = %s, date_record = %s, date_order = %s, Payment = %s WHERE OrderID = %s"
                self.cursor.execute(query, (
                new_client_id, new_worker_id, new_date_record, new_date_order, new_payment, order_id))
                self.db_connection.commit()
                self.show_orders()
        else:
            QMessageBox.warning(self, "Ошибка", "Выберите заказ для редактирования")

    def delete_order(self):
        row = self.result_table.currentRow()
        if row != -1:
            order_id = self.result_table.item(row, 0).text()
            reply = QMessageBox.question(self, 'Удаление заказа', 'Вы хотите удалить заказ?',
                                         QMessageBox.Yes | QMessageBox.No)
            if reply == QMessageBox.Yes:
                query = "DELETE FROM Orders WHERE OrderID = %s"
                self.cursor.execute(query, (order_id,))
                self.db_connection.commit()
                self.show_orders()
        else:
            QMessageBox.warning(self, "Ошибка", "Выберите заказ для удаления")

    def closeEvent(self, event):
        self.db_connection.close()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())